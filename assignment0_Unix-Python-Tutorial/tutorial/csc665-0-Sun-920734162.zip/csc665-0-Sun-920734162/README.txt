Name: Lun(Allen) Sun
SFSU ID: 920734162

For addition.py and buyLotsOfFruit.py, they help sum up values of a list.
In shorSmart.py, first get the total cost of each shop as a list, and then 
find the index of cheapest shop. At the end, return the cheapset shop.


Results:

Provisional grades
==================
Question q1: 1/1
Question q2: 1/1
Question q3: 1/1
------------------
Total: 3/3